import json
from datetime import datetime

def fetch_episodes():
    # هنا يمكن استبدال هذا الجزء بجلب الحلقات من المواقع
    episodes = [
        {
            "title": "المؤسس عثمان - الحلقة 1",
            "language": "مترجمة",
            "url": "https://www.youtube.com/watch?v=oTob1p7d9Yw",
            "thumbnail": "https://img.youtube.com/vi/oTob1p7d9Yw/0.jpg",
            "updated_at": datetime.utcnow().isoformat()
        }
    ]
    with open("episodes.json", "w", encoding="utf-8") as f:
        json.dump(episodes, f, ensure_ascii=False, indent=2)

if __name__ == "__main__":
    fetch_episodes()